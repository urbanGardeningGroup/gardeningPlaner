package org.vaadin.backend.domain;

/**
 * Created by synto on 15.11.2015.
 */
public enum FieldType {
    Circle, Rectangle
}
