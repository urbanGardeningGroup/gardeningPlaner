package org.vaadin.backend.domain;

public enum GardenStatus {
    Draft, Active, Inactive, NeedsAttention
}
