package org.vaadin.backend.domain;

public enum PlantStatus {
    planned, plantable, plantet, harvastable, harvasted, dead
}
