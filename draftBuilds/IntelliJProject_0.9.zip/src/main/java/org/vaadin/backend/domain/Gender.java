package org.vaadin.backend.domain;

public enum Gender {
    Female, Male
}
