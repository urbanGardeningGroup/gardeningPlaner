package org.vaadin.backend.domain;

public enum GardenType {
    GlassHouse, Normal, Patio, Pot
}
