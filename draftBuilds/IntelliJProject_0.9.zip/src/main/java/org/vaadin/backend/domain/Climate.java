package org.vaadin.backend.domain;

public enum Climate {
    Continental,
    Desert,
    Humid,
    Ice,
    Oceanic,
    Savannah,
    Steppe,
    Tropical,
    Tundra,
}
