package org.vaadin.backend.domain;

public enum CustomerStatus {
    ImportedLead, NotContacted, Contacted, Customer, ClosedLost
}
