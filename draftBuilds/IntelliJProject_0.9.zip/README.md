# Urban Garden Desinger

mvn install
cf login -u <ibmBluemixUser>
cf push <appname> -p target/<appname>.war